This project has been very hard on me. While coding it there are many times where i had accidentally wrote a big portion of code that worked sequentially which made it difficult to then parallelize after i realized my mistake. I had attempted at parallelizing the prefix method so each node can break up the work that was needed in order to make it function. As of right now there are major bugs in this project but I do not have the time to fix them or finish the code.

a) the theoretical time complexity for the best case would be (n/p)*hashrate*cryptTime and the worst case is if there is one more processor that has an extra line to check than the others.

b) Adding more nodes does not perfectly divide up the data as since the lines are 9999 there are only some cases in which itll actually divide up perfectly

c) My code was not completed in time to be able to be ran with different test cases or timers however i can imagine that using a fixed size number of the maximumn string length could possibly take over one thousand years at least

d) real worl examples can be when pen testers try to infiltrate a software or server and they find the users database and it includes an md5 hash for the passwords

e) My code needs to be re done and re planned out in general in order to actually have any better performance.