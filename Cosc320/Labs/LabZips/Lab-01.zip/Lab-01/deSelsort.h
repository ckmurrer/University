#ifndef DESELSORT_H
#define DESELSORT_H

#include <iostream>

class deSelsort{
    private:

    public:
        void sort(int* arr, int n);
};
#endif