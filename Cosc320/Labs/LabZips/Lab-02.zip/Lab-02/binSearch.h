/*
    Name: Cody Murrer
    Lab: 02 (Binary search lab)
    Class: 320-752
*/
#ifndef BINSEARCH_H
#define BINSEARCH_H

#include <iostream>

class binSearch{
    private:

    public:
        int search(int* arr, int l, int r, int x);
        void sort(int* arr, int n);
};
#endif